package com.example.mapd726_besttripapp_teamtravelers_n_sankjay.dataModel

class notificationsListModel (val title:String, val date:String, val notificationIcon:Int) {
}