package com.example.mapd726_besttripapp_teamtravelers_n_sankjay.dataModel

data class NotificationsListDataModel (

    var notiTitle: String = "",
    var notiDate: String = "",

)