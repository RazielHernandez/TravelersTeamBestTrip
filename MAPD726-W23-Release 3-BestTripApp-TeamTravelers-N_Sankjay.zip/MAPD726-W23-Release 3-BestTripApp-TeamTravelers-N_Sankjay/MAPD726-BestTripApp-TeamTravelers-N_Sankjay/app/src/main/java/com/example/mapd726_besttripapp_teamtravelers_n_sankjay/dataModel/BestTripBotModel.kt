package com.example.mapd726_besttripapp_teamtravelers_n_sankjay.dataModel

class BestTripBotModel (val chat:String, val img:Int) {
}